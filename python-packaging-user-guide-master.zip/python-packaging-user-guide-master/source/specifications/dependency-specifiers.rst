
.. _dependency-specifiers:

=====================
Dependency specifiers
=====================

The dependency specifier format used to declare a dependency on another
component is defined in :pep:`508`.

The environment markers section in this PEP supersedes the environment markers
section in :pep:`345`.
