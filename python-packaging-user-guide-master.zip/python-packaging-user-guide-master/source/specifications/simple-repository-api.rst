
.. _simple-repository-api:

=====================
Simple repository API
=====================

The current interface for querying available package versions and retrieving packages
from an index server is defined in :pep:`503`.
