
.. _version-specifiers:

==================
Version specifiers
==================

Version numbering requirements and the semantics for specifying comparisons
between versions are defined in :pep:`440`.

The version specifiers section in this PEP supersedes the version specifiers
section in :pep:`345`.
