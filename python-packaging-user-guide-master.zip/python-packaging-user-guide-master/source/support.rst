==================
How to Get Support
==================

For support related to a specific project, see the links on the :doc:`Projects
<key_projects>` page.

For something more general, or when you're just not sure, use the `distutils-sig
<http://mail.python.org/mailman/listinfo/distutils-sig>`_ list.
