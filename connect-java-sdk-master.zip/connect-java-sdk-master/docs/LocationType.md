
# LocationType

## Enum


* `PHYSICAL` (value: `"PHYSICAL"`)

* `MOBILE` (value: `"MOBILE"`)



