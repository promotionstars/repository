
# CustomerGroupInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The ID of the customer group. | 
**name** | **String** | The name of the customer group. | 



