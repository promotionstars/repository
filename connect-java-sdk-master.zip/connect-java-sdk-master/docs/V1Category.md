
# V1Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The category&#39;s unique ID. |  [optional]
**name** | **String** | The category&#39;s name. |  [optional]



