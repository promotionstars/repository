
# TenderType

## Enum


* `CARD` (value: `"CARD"`)

* `CASH` (value: `"CASH"`)

* `THIRD_PARTY_CARD` (value: `"THIRD_PARTY_CARD"`)

* `SQUARE_GIFT_CARD` (value: `"SQUARE_GIFT_CARD"`)

* `NO_SALE` (value: `"NO_SALE"`)

* `OTHER` (value: `"OTHER"`)



