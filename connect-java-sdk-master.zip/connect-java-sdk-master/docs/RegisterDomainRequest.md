
# RegisterDomainRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domainName** | **String** | A domain name as described in RFC-1034 that will be registered with ApplePay | 



