
# Device

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The device&#39;s Square-issued ID. |  [optional]
**name** | **String** | The device&#39;s merchant-specified name. |  [optional]



