
# TransactionProduct

## Enum


* `REGISTER` (value: `"REGISTER"`)

* `EXTERNAL_API` (value: `"EXTERNAL_API"`)

* `BILLING` (value: `"BILLING"`)

* `APPOINTMENTS` (value: `"APPOINTMENTS"`)

* `INVOICES` (value: `"INVOICES"`)

* `ONLINE_STORE` (value: `"ONLINE_STORE"`)

* `PAYROLL` (value: `"PAYROLL"`)

* `OTHER` (value: `"OTHER"`)



