
# RetrieveTransactionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;Error&gt;**](Error.md) | Any errors that occurred during the request. |  [optional]
**transaction** | [**Transaction**](Transaction.md) | The requested transaction. |  [optional]



