
# CatalogQueryItemsForModifierList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modifierListIds** | **List&lt;String&gt;** | A set of [CatalogModifierList](#type-catalogmodifierlist) IDs to be used to find associated [CatalogItem](#type-catalogitem)s. | 



