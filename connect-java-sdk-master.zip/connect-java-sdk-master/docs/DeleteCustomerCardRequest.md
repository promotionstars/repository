
# DeleteCustomerCardRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



