
# CaptureTransactionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



