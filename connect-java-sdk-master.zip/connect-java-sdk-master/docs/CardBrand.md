
# CardBrand

## Enum


* `OTHER_BRAND` (value: `"OTHER_BRAND"`)

* `VISA` (value: `"VISA"`)

* `MASTERCARD` (value: `"MASTERCARD"`)

* `AMERICAN_EXPRESS` (value: `"AMERICAN_EXPRESS"`)

* `DISCOVER` (value: `"DISCOVER"`)

* `DISCOVER_DINERS` (value: `"DISCOVER_DINERS"`)

* `JCB` (value: `"JCB"`)

* `CHINA_UNIONPAY` (value: `"CHINA_UNIONPAY"`)

* `SQUARE_GIFT_CARD` (value: `"SQUARE_GIFT_CARD"`)



