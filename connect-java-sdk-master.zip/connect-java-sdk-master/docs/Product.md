
# Product

## Enum


* `SQUARE_POS` (value: `"SQUARE_POS"`)

* `EXTERNAL_API` (value: `"EXTERNAL_API"`)

* `BILLING` (value: `"BILLING"`)

* `APPOINTMENTS` (value: `"APPOINTMENTS"`)

* `INVOICES` (value: `"INVOICES"`)

* `ONLINE_STORE` (value: `"ONLINE_STORE"`)

* `PAYROLL` (value: `"PAYROLL"`)

* `DASHBOARD` (value: `"DASHBOARD"`)

* `ITEM_LIBRARY_IMPORT` (value: `"ITEM_LIBRARY_IMPORT"`)

* `OTHER` (value: `"OTHER"`)



