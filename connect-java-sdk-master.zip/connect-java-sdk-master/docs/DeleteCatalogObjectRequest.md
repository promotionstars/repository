
# DeleteCatalogObjectRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



