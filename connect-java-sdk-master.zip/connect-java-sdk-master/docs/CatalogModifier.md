
# CatalogModifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The modifier&#39;s name. Searchable. |  [optional]
**priceMoney** | [**Money**](Money.md) | The modifier&#39;s price. |  [optional]



