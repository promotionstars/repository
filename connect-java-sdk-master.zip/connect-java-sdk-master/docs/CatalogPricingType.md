
# CatalogPricingType

## Enum


* `FIXED_PRICING` (value: `"FIXED_PRICING"`)

* `VARIABLE_PRICING` (value: `"VARIABLE_PRICING"`)



