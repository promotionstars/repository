
# RetrieveTransactionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



