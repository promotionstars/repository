
# CatalogQueryExact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attributeName** | **String** | The name of the attribute to be searched. | 
**attributeValue** | **String** | The desired value of the search attribute. | 



