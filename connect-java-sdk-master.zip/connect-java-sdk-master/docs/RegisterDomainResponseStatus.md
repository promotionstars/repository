
# RegisterDomainResponseStatus

## Enum


* `PENDING` (value: `"PENDING"`)

* `VERIFIED` (value: `"VERIFIED"`)



