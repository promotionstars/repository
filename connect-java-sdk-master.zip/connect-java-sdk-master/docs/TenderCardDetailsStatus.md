
# TenderCardDetailsStatus

## Enum


* `AUTHORIZED` (value: `"AUTHORIZED"`)

* `CAPTURED` (value: `"CAPTURED"`)

* `VOIDED` (value: `"VOIDED"`)

* `FAILED` (value: `"FAILED"`)



