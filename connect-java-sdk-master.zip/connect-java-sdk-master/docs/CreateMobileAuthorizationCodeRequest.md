
# CreateMobileAuthorizationCodeRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locationId** | **String** | The Square location ID the authorization code should be tied to. |  [optional]



