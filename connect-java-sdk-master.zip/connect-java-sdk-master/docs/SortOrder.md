
# SortOrder

## Enum


* `DESC` (value: `"DESC"`)

* `ASC` (value: `"ASC"`)



