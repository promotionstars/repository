
# CatalogItemProductType

## Enum


* `REGULAR` (value: `"REGULAR"`)

* `GIFT_CARD` (value: `"GIFT_CARD"`)

* `APPOINTMENTS_SERVICE` (value: `"APPOINTMENTS_SERVICE"`)

* `RETAIL_ITEM` (value: `"RETAIL_ITEM"`)

* `RESTAURANT_ITEM` (value: `"RESTAURANT_ITEM"`)



