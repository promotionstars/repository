
# ListLocationsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;Error&gt;**](Error.md) | Any errors that occurred during the request. |  [optional]
**locations** | [**List&lt;Location&gt;**](Location.md) | The business&#39;s locations. |  [optional]



