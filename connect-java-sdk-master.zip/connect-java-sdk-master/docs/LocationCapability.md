
# LocationCapability

## Enum


* `PROCESSING` (value: `"CREDIT_CARD_PROCESSING"`)



