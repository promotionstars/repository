
# CustomerPreferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emailUnsubscribed** | **Boolean** | The customer has unsubscribed from receiving marketing campaign emails. |  [optional]



