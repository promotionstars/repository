
# CatalogCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The category&#39;s name. Searchable. |  [optional]



