
# V1MerchantLocationDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nickname** | **String** | The nickname assigned to the single-location account by the parent business. This value appears in the parent business&#39;s multi-location dashboard. |  [optional]



