
# CustomerCreationSource

## Enum


* `OTHER` (value: `"OTHER"`)

* `APPOINTMENTS` (value: `"APPOINTMENTS"`)

* `COUPON` (value: `"COUPON"`)

* `DELETION_RECOVERY` (value: `"DELETION_RECOVERY"`)

* `DIRECTORY` (value: `"DIRECTORY"`)

* `EGIFTING` (value: `"EGIFTING"`)

* `EMAIL_COLLECTION` (value: `"EMAIL_COLLECTION"`)

* `FEEDBACK` (value: `"FEEDBACK"`)

* `IMPORT` (value: `"IMPORT"`)

* `INVOICES` (value: `"INVOICES"`)

* `LOYALTY` (value: `"LOYALTY"`)

* `MARKETING` (value: `"MARKETING"`)

* `MERGE` (value: `"MERGE"`)

* `ONLINE_STORE` (value: `"ONLINE_STORE"`)

* `INSTANT_PROFILE` (value: `"INSTANT_PROFILE"`)

* `TERMINAL` (value: `"TERMINAL"`)

* `THIRD_PARTY` (value: `"THIRD_PARTY"`)

* `THIRD_PARTY_IMPORT` (value: `"THIRD_PARTY_IMPORT"`)

* `UNMERGE_RECOVERY` (value: `"UNMERGE_RECOVERY"`)



