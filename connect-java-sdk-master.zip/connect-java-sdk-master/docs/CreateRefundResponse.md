
# CreateRefundResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;Error&gt;**](Error.md) | Any errors that occurred during the request. |  [optional]
**refund** | [**Refund**](Refund.md) | The created refund. |  [optional]



