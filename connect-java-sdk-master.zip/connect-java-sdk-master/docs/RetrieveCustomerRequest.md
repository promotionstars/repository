
# RetrieveCustomerRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



