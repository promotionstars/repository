
# V1PhoneNumber

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callingCode** | **String** | The phone number&#39;s international calling code. For US phone numbers, this value is +1. | 
**number** | **String** | The phone number. | 



