
# V1ItemImage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The image&#39;s unique ID. |  [optional]
**url** | **String** | The image&#39;s publicly accessible URL. |  [optional]



