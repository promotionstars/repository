
# RevokeTokenResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** | If the request is successful, this is true. |  [optional]



