
# TimeRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startAt** | **String** | A datetime value in RFC-3339 format indicating when the time range starts. |  [optional]
**endAt** | **String** | A datetime value in RFC-3339 format indicating when the time range ends. |  [optional]



