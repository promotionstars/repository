
# VoidTransactionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



